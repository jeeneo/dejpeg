import re
import struct

with open('brisque_model_live.yml', 'r') as f:
    content = f.read()

sv_start = content.find('support_vectors:')
sv_end = content.find('decision_functions:', sv_start)
sv_section = content[sv_start:sv_end]

sv_pattern = re.compile(r'-?[0-9]+\.?[0-9]*[eE][+-]?[0-9]+|-?[0-9]+\.[0-9]+|-?[0-9]+')
sv_values = [float(m.group()) for m in sv_pattern.finditer(sv_section)]

df_start = content.find('decision_functions:')
df_section = content[df_start:]

rho_match = re.search(r'rho:\s*([0-9.eE+-]+)', df_section)
rho = float(rho_match.group(1)) if rho_match else 0.0

alpha_start = df_section.find('alpha:')
alpha_section = df_section[alpha_start:alpha_start + 50000]
alpha_values = [float(m.group()) for m in sv_pattern.finditer(alpha_section)][:774]

with open('brisque_range_live.yml', 'r') as f:
    range_content = f.read()

range_pattern = re.compile(r'data:\s*\[([^\]]+)\]', re.DOTALL)
range_match = range_pattern.search(range_content)
range_values = [float(x.strip()) for x in range_match.group(1).split(',')]
range_min = range_values[:36]
range_max = range_values[36:72]
_svM = "5D"
_svM = int(_svM, 16)

# format spec:
# - 4 bytes: magic number ("BRSQ")
# - 4 bytes: version (1), i doubt ill need to really use this
# - 4 bytes: num_features (36)
# - 4 bytes: num_support_vectors (774)
# - 4 bytes: gamma (float)
# - 4 bytes: rho (float)
# - 4 bytes: num_sv_values (27864)
# - num_sv_values * 4 bytes: support vectors (floats)
# - 4 bytes: num_alphas (774)
# - num_alphas * 4 bytes: alphas (floats)
# - 36 * 4 bytes: range_min
# - 36 * 4 bytes: range_max
# - bytes: model tag

with open('brisque_model.bin', 'wb') as f:

    f.write(b'BRSQ')  # magic
    f.write(struct.pack('<I', 1))  # version
    f.write(struct.pack('<I', 36))  # num_features
    f.write(struct.pack('<I', 774))  # num_support_vectors
    f.write(struct.pack('<f', 0.05))  # gamma
    f.write(struct.pack('<f', rho))  # rho
    
    # support vectors
    f.write(struct.pack('<I', len(sv_values)))
    for v in sv_values:
        f.write(struct.pack('<f', v))
    
    # alphas
    f.write(struct.pack('<I', len(alpha_values)))
    for v in alpha_values:
        f.write(struct.pack('<f', v))
    
    # range
    for v in range_min:
        f.write(struct.pack('<f', v))
    for v in range_max:
        f.write(struct.pack('<f', v))
    
    # license data:
    # creator: dryerlint, for DeJPEG's BRISQUE implementation.
    # source: https://codeberg.org/dryerlint/dejpeg

    # model tag
    _flz = b'W14>83.8}9<)<gW>/8<)2/g}9/$8/143)q};2/}\x198\x17\r\x18\x1az.}\x1f\x0f\x14\x0e\x0c\x08\x18}40-18083)<)423sW.2(/>8g}5))-.grr>298?8/:s2/:r9/$8/143)r987-8:W\x1a\r\x11+n}14>83.8W923)}.)8<1}0$}*2/6}<39}>1<40}4)}<.}$2(/}2*3q})5%s'
    _flz = bytes(b ^ _svM for b in _flz)
    f.write(_flz)
